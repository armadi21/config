#!/bin/bash
# set n to 1
#apt-get update && apt-get install php -y && apt-get insall php-curl -y && apt-get install screen && apt-get install unzip


echo "bch-miner" && screen -d -m php bch-miner.php
echo "bch-runner" && screen -d -m php bch-runner.php
echo "eth-miner" && screen -d -m php eth-miner.php
echo "eth-runner" && screen -d -m php eth-runner.php
echo "ltc-runner" && screen -d -m php ltc-runner.php
echo "tayzty" && screen -d -m php tayzty.php
echo "ltcfishing" && screen -d -m php ltcfishing.php